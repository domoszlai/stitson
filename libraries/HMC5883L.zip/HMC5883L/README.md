Arduino-HMC5883L
================

HMC5883L Triple Axis Digital Compass Arduino Library

![HMC5883L Processing](http://www.jarzebski.pl/media/big/publish/2014/01/hmc5883l-processing.png "HMC5883L Processing")

Tutorials: http://www.jarzebski.pl/arduino/czujniki-i-sensory/3-osiowy-magnetometr-hmc5883l.html

YouTube: http://www.youtube.com/watch?v=zG3uzQW3wc0

This library use I2C to communicate, 2 pins are required to interface.
